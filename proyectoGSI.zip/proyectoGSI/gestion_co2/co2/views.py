# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'index.html', context={'nombre_empresa': 'Empresa'})

def add(request):
	return render(request, 'addco2.html', context={'nombre_empresa': 'Empresa'})