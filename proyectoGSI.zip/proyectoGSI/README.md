Escartin Marcotegui, Ibon 

Iriarte Saralegui, Amaia

Dominguez Serrano, Diana

Proyecto final para la asignatura de gestión de sistemas de información
